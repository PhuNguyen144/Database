﻿--Q27--
SELECT COUNT(*) AS SoLuongGV, SUM(Luong) AS TongLuong
FROM GIAO_VIEN

--Q28--
SELECT gv.MaBM, COUNT(gv.MaGV) AS TongGV, AVG(gv.Luong) AS LuongTB
FROM GIAO_VIEN gv
GROUP BY gv.MaBM

--Q29--
SELECT cd.TenCD, count(dt.MaDT) AS TongDT
FROM DE_TAI dt join CHU_DE cd ON dt.MaCD = cd.MaCD
GROUP BY dt.MaCD, cd.TenCD

--30--
SELECT GV.HoTen, COUNT(DT.MaDT) AS SoLuongGV
FROM DE_TAI dt join GIAO_VIEN gv on dt.GVCNDT=gv.MaGV
GROUP BY dt.GVCNDT,gv.HoTen
--31--
SELECT gv.HoTen, COUNT(DISTINCT nt.HoTen) AS SoLuongGV
FROM NGUOI_THAN nt join GIAO_VIEN gv on nt.MaGV=gv.MaGV
GROUP BY nt.MaGV,gv.HoTen

--32--
SELECT gv.HoTen, COUNT(DISTINCT nt.HoTen) AS SoLuongGV
FROM NGUOI_THAN nt join GIAO_VIEN gv ON nt.MaGV=gv.MaGV
GROUP BY nt.MaGV, gv.HoTen

--33--
SELECT gv.HOTEN
FROM GIAO_VIEN gv join THAM_GIA_DT tg ON gv.MaGV = tg.MaGV
GROUP BY gv.MaGV,gv.HoTen
HAVING COUNT(DISTINCT tg.MADT)>= 3

--34--
SELECT COUNT(DISTINCT tg.MaGV) AS SoLuongGV
FROM THAM_GIA_DT tg join DE_TAI dt ON tg.MaDT = dt.MaDT
WHERE dt.TenDT = N'Ứng dụng hóa học xanh'
GROUP BY tg.MaDT
